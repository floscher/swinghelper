package org.jdesktop.swinghelper.layer.demo;

import org.jdesktop.swinghelper.layer.JXLayer;
import org.jdesktop.swinghelper.layer.painter.Painter;
import org.jdesktop.swinghelper.layer.painter.AbstractPainter;
import org.jdesktop.swinghelper.layer.painter.AbstractBufferedPainter;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class SpotLightPainter<V extends JComponent> 
        extends AbstractPainter<V> {

    /**
     * Clip list for this painter.
     */
    private ArrayList<Shape> clipList = new ArrayList<Shape>();

    /**
     * Overlay color for the non-matching items.
     */
    private Color overlayColor;

    /**
     * Foreground painter.
     */
    private Painter<V> foregroundPainter;

    private int softClipWidth;

    /**
     * Creates a simple spotlight painter.
     */
    public SpotLightPainter() {
        this(0);
    }
    
    public SpotLightPainter(int softClipWidth) {
        this(new Color(0, 0, 0, 128), softClipWidth);
    }
    
    public SpotLightPainter(final Color overlayColor, int softClipWidth) {
        setOverlayColor(overlayColor);
        setSoftClipWidth(softClipWidth);

        // AbstractBufferedPainter.getModel().isIncrementalUpdate() is false by default
        // so this painter will cache its buffer and repaint itself only
        // when the whole layer is repainted
        this.foregroundPainter = new AbstractBufferedPainter<V>() {
            @Override
            protected void paintToBuffer(Graphics2D g2, JXLayer<V> l) {
                g2.setComposite(AlphaComposite.Clear);
                g2.fillRect(0, 0, l.getWidth(), l.getHeight());
                g2.setComposite(AlphaComposite.SrcOver);
                g2.setColor(overlayColor);
                g2.fillRect(0, 0, l.getWidth(), l.getHeight());
                for (Shape shape : clipList) {
                    g2.setClip(shape);
                    g2.setComposite(AlphaComposite.Clear);
                    g2.fill(shape);
                    softClipping(g2, shape);
                }
            }
        };
    }

    private void softClipping(Graphics2D g2, Shape shape) {
        g2.setComposite(AlphaComposite.Src);
        for (int i = 0; i < softClipWidth; i++) {
            int alpha = (i + 1) * overlayColor.getAlpha()
                    / (softClipWidth + 1);
            Color temp = new Color(
                    overlayColor.getRed(),
                    overlayColor.getGreen(), 
                    overlayColor.getBlue(), alpha);
            g2.setColor(temp);
            g2.setStroke(new BasicStroke(softClipWidth - i));
            g2.draw(shape);
        }
    }

    public Color getOverlayColor() {
        return overlayColor;
    }

    public void setOverlayColor(Color overlayColor) {
        if (overlayColor == null) {
            throw new IllegalArgumentException("overlayColor is null");
        }
        this.overlayColor = overlayColor;
        fireLayerItemChanged();
    }

    public int getSoftClipWidth() {
        return softClipWidth;
    }

    public void setSoftClipWidth(int softClipWidth) {
        if (softClipWidth < 0) {
            throw new IllegalArgumentException("softClipWidth can't be less than 0");
        }
        this.softClipWidth = softClipWidth;
        fireLayerItemChanged();
    }

    /**
     * Resets this painter.
     */
    public void reset() {
        clipList.clear();
        fireLayerItemChanged();
    }

    /**
     * Adds the specified shape to the slip list.
     *
     * @param shape Shape to add to the clip list.
     */
    public void addShape(Shape shape) {
        clipList.add(shape);
    }

    @Override
    public void paint(Graphics2D g2, JXLayer<V> l) {
        l.paint(g2);
        foregroundPainter.paint(g2, l);
    }

    @Override
    public boolean contains(int x, int y, JXLayer<V> l) {
        for (Shape shape : clipList) {
            if (shape.contains(x, y)) {
                return true;
            }
        }
        return false;
    }
}

