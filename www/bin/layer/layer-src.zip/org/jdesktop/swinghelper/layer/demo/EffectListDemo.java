package org.jdesktop.swinghelper.layer.demo;

import org.jdesktop.swinghelper.layer.JXLayer;
import org.jdesktop.swinghelper.layer.painter.Painter;
import org.jdesktop.swinghelper.layer.effectlist.DefaultEffectList;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImageOp;

public class EffectListDemo {
    public static void main(String[] args) throws Exception {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setLayout(new FlowLayout());

        JXLayer l = new JXLayer(new JButton("Hello"));

        l.setEffectList(new DefaultEffectList() {
            public BufferedImageOp getBufferedImageOp(BufferedImageOp bio, JXLayer l) {
                JButton b = (JButton) l.getContentPane();
                if (b.getModel().isPressed()) {
                    return BufferedImageOps.getConvolveOp(3);
                }
                return super.getBufferedImageOp(bio, l);
            }

            public Painter getForegroundPainter(Painter p, JXLayer l) {
                JButton b = (JButton) l.getContentPane();
                if (b.getModel().isRollover() || b.getModel().isPressed()) {
                    return new Painter() {
                        public void paint(Graphics2D g2, JXLayer l) {
                            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, .3f));
                            g2.setColor(Color.RED);
                            g2.fillRect(0, 0, 30, 30);
                        }
                    };
                }
                return super.getForegroundPainter(p, l);
            }

            public boolean isForegroundPainterOrigin(boolean b, JXLayer l) {
                return false;
            }
        });


        frame.add(l);

        frame.setSize(200, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
