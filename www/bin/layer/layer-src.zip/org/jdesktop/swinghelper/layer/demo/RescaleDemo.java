package org.jdesktop.swinghelper.layer.demo;

import org.jdesktop.swinghelper.layer.JXLayer;
import org.jdesktop.swinghelper.layer.effect.ImageOpEffect;
import org.jdesktop.swinghelper.layer.painter.Painter;
import org.jdesktop.swinghelper.layer.painter.BufferedPainter;
import org.jdesktop.swinghelper.layer.painter.DefaultPainter;

import javax.swing.*;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.*;
import java.awt.image.RescaleOp;

public class RescaleDemo extends JFrame {
    private ImageOpEffect effect = new ImageOpEffect(null);

    public RescaleDemo() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JXLayer<JComponent> l = new JXLayer<JComponent>(new JButton("Hello"));
        BufferedPainter<JComponent> p =
                new BufferedPainter<JComponent>(new DefaultPainter<JComponent>());
        l.setPainter(p);

        p.setEffects(effect);

        add(l);

        add(createToolPanel(), BorderLayout.WEST);

        setSize(400, 200);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private JPanel createToolPanel() {
        JPanel ret = new JPanel(new GridLayout(0, 1));
        final JSlider redSlider = new JSlider(0, 200, 100);
        ret.add(redSlider);
        final JSlider greenSlider = new JSlider(0, 200, 100);
        ret.add(greenSlider);
        final JSlider blueSlider = new JSlider(0, 200, 100);
        ret.add(blueSlider);

        ChangeListener colorChangeListener = new ChangeListener() {
            public void stateChanged(ChangeEvent e) {

                float[] factors = {100f / redSlider.getValue(),
                        100f / greenSlider.getValue(),
                        100f / blueSlider.getValue(), 1};
                effect.setBufferedImageOp(new RescaleOp(factors, new float[4], null));

            }
        };
        redSlider.addChangeListener(colorChangeListener);
        greenSlider.addChangeListener(colorChangeListener);
        blueSlider.addChangeListener(colorChangeListener);

        return ret;
    }

    public static void main(String[] args) throws Exception {
        new RescaleDemo();
    }
}
