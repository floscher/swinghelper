package org.jdesktop.swinghelper.layer.demo;

import org.jdesktop.swinghelper.layer.JXLayer;
import org.jdesktop.swinghelper.layer.painter.ComponentPainter;

import javax.swing.*;
import java.awt.*;

public class ComponentPainterDemo {
    public static void main(String[] args) throws Exception {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());
        
        JButton button = new JButton("Hello");
        button.setSize(button.getPreferredSize());        
        frame.add(button);

        JXLayer l = new JXLayer(new ComponentPainter(button));
        l.setPreferredSize(button.getPreferredSize());
        frame.add(l);

        frame.setSize(200, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
