package org.jdesktop.swinghelper.layer.demo;

import org.jdesktop.swinghelper.layer.JXLayer;
import org.jdesktop.swinghelper.layer.painter.Painter;
import org.jdesktop.swinghelper.layer.painter.AbstractPainter;

import javax.swing.*;
import java.awt.*;

public class BioTest {
    public static void main(String[] args) throws Exception {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());
        JComponent c = new JButton("Hello");
//        c.setOpaque(false);
//        c.setBorder(BorderFactory.createEtchedBorder());
        c.setPreferredSize(new Dimension(100, 100));
        JXLayer l = new JXLayer(c);
        frame.add(l);

        l.setBackgroundPainter(new AbstractPainter() {
            public void paint(Graphics2D g2, JXLayer l) {
                g2.setColor(Color.red);
                g2.fillRect(0,0,l.getWidth(), l.getHeight());
            }
        });

        l.setForegroundPainter(new AbstractPainter(false) {
            public void paint(Graphics2D g2, JXLayer l) {
                g2.setColor(Color.BLUE);
                g2.fillOval(0,0,l.getWidth()/2, l.getHeight()/2);
            }
        });
        l.setBufferedImageOp(BufferedImageOps.getConvolveOp(5));
//        l.setOpaque(false);
        l.setAlpha(.5f);
        
        frame.getGlassPane().setVisible(true);
        
        frame.setSize(200, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
