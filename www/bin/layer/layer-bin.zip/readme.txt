
Translucency, BufferedImageOps and Painters demo

java -cp layer.jar;layer-demo.jar org.jdesktop.swinghelper.layer.demo.InternalFrameDemo

===

Non rectagular shapes support

java -cp layer.jar;layer-demo.jar org.jdesktop.swinghelper.layer.demo.ShapingAnimationDemo

===

JTabbedPane Animation Demo

java -cp layer.jar;layer-demo.jar org.jdesktop.swinghelper.layer.demo.TabbedPaneAnimationDemo

===

GlassPane effect demo

java -cp layer.jar;layer-demo.jar org.jdesktop.swinghelper.layer.demo.GlassPaneDemo

===

Delegation demo
(Changing view of a component without sublclassing)

java -cp layer.jar;layer-demo.jar org.jdesktop.swinghelper.layer.demo.DelegateDemo