package org.jdesktop.swinghelper.test;

import org.jdesktop.swinghelper.debug.CheckThreadViolationRepaintManager;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;
import javax.swing.text.html.HTMLEditorKit;
import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

/** @author JohnM */

public class EditorPaneEDTViolation extends JFrame{
    static JEditorPane msgArea;

    public EditorPaneEDTViolation() {
        setTitle("EDT Violations R Us");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        msgArea = new JEditorPane();
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.add(msgArea);
        add(p, BorderLayout.CENTER);

        setBounds(100, 100, 800, 600);
    }

    public static void main(String[] args) {

        Properties systemproperties = System.getProperties();
        systemproperties.put("proxyHost",
                             "webcache.sfbay.sun.com");// http proxy server
        systemproperties.put("proxyPort",
                             "8080");              // http port #
        systemproperties.put("proxySet","true");

        System.setProperties(systemproperties);

        EventQueue.invokeLater(new Runnable(){
            public void run(){
                RepaintManager.setCurrentManager(new CheckThreadViolationRepaintManager());
                
                final EditorPaneEDTViolation epv = new EditorPaneEDTViolation();
                epv.setVisible(true);
                try {
/*
                    msgArea.setEditorKit(new HTMLEditorKit() {
                        public Document createDefaultDocument() {
                            Document doc = super.createDefaultDocument();
                            doc.addDocumentListener(new DocumentListener() {
                                public void insertUpdate(DocumentEvent e) {
                                    if (!SwingUtilities.isEventDispatchThread()) {
                                        System.out.println("Error !!!");
                                    }
                                }

                                public void removeUpdate(DocumentEvent e) {
                                    if (!SwingUtilities.isEventDispatchThread()) {
                                        System.out.println("Error !!!");
                                    }
                                }

                                public void changedUpdate(DocumentEvent e) {
                                    if (!SwingUtilities.isEventDispatchThread()) {
                                        System.out.println("Error !!!");
                                    }
                                }
                            });
                            return doc;
                        }
                    });
*/
                    msgArea.setPage(new URL("http://www.google.com"));

                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }
}